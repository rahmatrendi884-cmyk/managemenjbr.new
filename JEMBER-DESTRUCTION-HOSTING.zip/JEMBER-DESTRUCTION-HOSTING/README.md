# JEMBER DESTRUCTION — Hosting Package

## Isi paket
- `index.html` — halaman utama aplikasi.
- `assets/css/style.css` — CSS tambahan.
- `assets/js/app.js` — logika toko, checkout, admin, pesanan, dan keuangan.
- `assets/js/tailwind.config.js` — konfigurasi Tailwind.
- `config/config.example.js` — contoh konfigurasi koneksi backend.

## Perbaikan yang sudah diterapkan
1. JavaScript dipisahkan dari HTML dan CSS.
2. Memperbaiki bug tambah produk: fungsi duplikat yang menimpa implementasi varian warna dinamis dihapus.
3. Data produk, pesanan, keuangan, profil toko, dan status follow disimpan otomatis di `localStorage`.
4. Foto yang diunggah dikecilkan/dikompresi sebelum disimpan untuk mengurangi pemakaian ruang.
5. ID produk dan pesanan memakai penanda waktu agar tidak mudah bentrok setelah data dihapus.
6. Ditambahkan pemberitahuan bahwa penyimpanan saat ini hanya lokal.

## Cara menjalankan
- Ekstrak ZIP.
- Buka `index.html` melalui browser atau jalankan server lokal sederhana.
- Untuk pengujian lokal, disarankan memakai Live Server di VS Code.

## Cara hosting statis
### Netlify
1. Login ke Netlify.
2. Pilih **Add new site → Deploy manually**.
3. Unggah folder hasil ekstrak (atau ZIP).
4. Pastikan `index.html` berada di root folder deploy.

### Vercel
1. Upload folder ini ke repository GitHub.
2. Import repository di Vercel.
3. Framework preset: **Other**; Build command dikosongkan; Output directory: `.`.
4. Deploy.

### cPanel
1. Buka File Manager → `public_html`.
2. Upload ZIP, lalu Extract.
3. Pastikan `index.html` berada langsung di `public_html`, bukan di subfolder bertingkat.

## PENTING: batasan sebelum toko dipakai publik
Versi ini masih frontend statis dengan `localStorage`. Data hanya ada di browser/perangkat yang dipakai; data pelanggan dari perangkat lain tidak otomatis masuk ke dashboard admin. Membersihkan data browser juga dapat menghapus data toko.

Login admin bawaan pada versi asal (`admin` / `admin123` dan PIN `123456`) masih berupa pemeriksaan di JavaScript browser. Ini **bukan keamanan produksi** dan dapat dilihat oleh pengunjung yang memahami source code. Jangan gunakan kredensial ini untuk toko publik.

Untuk penggunaan nyata, perlu tahap backend:
- Database bersama untuk produk, pesanan, pembayaran, dan arus kas.
- Autentikasi admin server-side (hapus kredensial demo dari frontend).
- Penyimpanan gambar di object storage, bukan `localStorage`.
- Aturan akses database agar pelanggan hanya dapat membuat pesanan dan tidak dapat membaca data pelanggan lain.
- Konfigurasi webhook/konfirmasi pembayaran jika diperlukan.

`config/config.example.js` hanya template konfigurasi; backend belum terhubung dan belum ada kredensial rahasia di paket ini.

## Catatan
Library Tailwind, ikon Phosphor, SheetJS, dan font eksternal dimuat dari CDN; hosting membutuhkan koneksi internet.
