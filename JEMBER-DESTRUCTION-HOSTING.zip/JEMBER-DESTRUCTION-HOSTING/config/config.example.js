// Konfigurasi integrasi backend (opsional, belum dipakai aplikasi ini).
// Jangan pernah menaruh service_role key atau password admin di file frontend.
window.APP_CONFIG = {
  backend: 'supabase',
  supabaseUrl: 'ISI_URL_PROJECT_SUPABASE',
  supabaseAnonKey: 'ISI_ANON_PUBLIC_KEY'
};
